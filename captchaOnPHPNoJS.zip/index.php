<? session_start();
if (isset($_SESSION['captcha'])) {
  $captcha = $_SESSION['captcha'];
}

if (isset($_POST['captcha'])) {
  $code = $_POST['captcha'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    * {
      font-size: 16px;
      box-sizing: border-box;
      font-family: Arial, Helvetica, sans-serif;
    }

    form {
      display: flex;
      flex-direction: column;
      max-width: 300px;
      margin: 20px auto;
      width: 100%;
      gap: 10px;
    }

    button {
      padding: 7px 10px;
      border-radius: 10px;
      outline: none;
    }

    img {
      align-self: center;
      width: 300px;
      border-radius: 5px;
    }

    input {
      border-radius: 5px;
      padding: 7px 10px;
    }
  </style>

</head>

<body>
  <form
    method="post">
    <?
    if (isset($code) && isset($captcha))
      if ($captcha == $code) {
        echo 'Форма успешно отправлена!';
      } else {
        echo 'Введенный код не соответствует изображению!';
      }

    ?>
    <img
      src="/assets/php/captcha.php"
      alt="captcha" />
    <br>
    <label for="captcha">Код, изображенный на картинке:</label>
    <input type="text" name="captcha" />
    <button type="submit">Отправить</button>
  </form>
</body>

</html>