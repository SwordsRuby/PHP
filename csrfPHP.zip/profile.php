<?php
// Вставь подключение к базе данных
require 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    echo "Вы не авторизованы!";
    exit;
}

// Получаем данные о пользователе
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user) {
    echo "Пользователь не найден!";
    exit;
}
?>

<h2>Профиль</h2>
<p>Имя пользователя: <?= htmlspecialchars($user['username']) ?></p>
<p>Текущий email: <?= ''//htmlspecialchars($user['email']) ?></p>
<!-- Пароль не выводим, так как это небезопасно -->
<p>Пароль: скрыт для безопасности</p>
