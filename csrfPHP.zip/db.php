<?php
$pdo = new PDO('mysql:host=MySQL-8.2;dbname=csrf_test', 'root', '');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
session_start();
