<?php
echo __DIR__;
require_once __DIR__ . '/db.php';
echo " — db.php подключен!";
