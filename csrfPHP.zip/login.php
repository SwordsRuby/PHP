<?php
require_once __DIR__ . '/db.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
    $stmt->execute([$_POST['email'], $_POST['password']]);
    $user = $stmt->fetch();

    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        header("Location: profile.php");
        exit;
    } else {
        echo "Неверные данные!";
    }
}
?>

<form method="post">
    <input name="email" placeholder="Логин">
    <input name="password" placeholder="Пароль" type="password">
    <button type="submit">Войти</button>
</form>