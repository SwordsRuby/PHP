<?php
require 'db.php';
require 'csrf.php';

if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit;
}

$email = $_POST['username'] ?? '';

// CSRF-проверка (раскомментируй для защищённой версии)

// if (!verifyToken($_POST['csrf_token'] ?? '')) {
//   die("CSRF токен недействителен!");
// }


$stmt = $pdo->prepare("UPDATE users SET username = ? WHERE id = ?");
$stmt->execute([$email, $_SESSION['user_id']]);

echo "Email обновлён!";
