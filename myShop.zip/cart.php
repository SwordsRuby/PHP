<?php
$query = 'SELECT * FROM basket JOIN products ON basket_product = product_id AND basket_user = ?';
$stmt = $database->prepare($query);
$stmt->execute([$_SESSION['userId']]);
$products = $stmt->fetchAll();

$sum = 0;
?>

<?
if (isset($_POST['cartIdAdd'])) {
    $query = 'SELECT * FROM basket WHERE basket_product = ? AND basket_user = ?';
    $stmt = $database->prepare($query);
    $stmt->execute([$_POST['cartIdAdd'], $_SESSION['userId']]);
    $inBasket = $stmt->fetch();

    $query = 'SELECT * FROM products WHERE product_id = ?';
    $stmt = $database->prepare($query);
    $stmt->execute([$_POST['cartIdAdd']]);
    $product = $stmt->fetch();

    if ($inBasket && $product) {
        $query = 'UPDATE basket SET basket_count = basket_count + 1 WHERE basket_product = ? AND basket_user = ?';
        $stmt = $database->prepare($query);
        $stmt->execute([$_POST['cartIdAdd'], $_SESSION['userId']]);
    } else if ($product) {
        $query = 'INSERT INTO basket (basket_product, basket_user, basket_count) VALUES (?, ?, ?)';
        $stmt = $database->prepare($query);
        $stmt->execute([$_POST['cartIdAdd'], $_SESSION['userId'], 1]);
    }

    header('Refresh: 0');
}

if (isset($_POST['cartIdRemove'])) {
    $query = 'SELECT * FROM basket WHERE basket_product = ? AND basket_user = ?';
    $stmt = $database->prepare($query);
    $stmt->execute([$_POST['cartIdRemove'], $_SESSION['userId']]);
    $inBasket = $stmt->fetch();

    $query = 'SELECT * FROM products WHERE product_id = ?';
    $stmt = $database->prepare($query);
    $stmt->execute([$_POST['cartIdRemove']]);
    $product = $stmt->fetch();

    if ($inBasket && $product && $inBasket['basket_count'] != 1) {
        $query = 'UPDATE basket SET basket_count = basket_count - 1 WHERE basket_product = ? AND basket_user = ?';
        $stmt = $database->prepare($query);
        $stmt->execute([$_POST['cartIdRemove'], $_SESSION['userId']]);
    } else if ($inBasket && $product && $inBasket['basket_count'] == 1) {
        $query = 'DELETE FROM basket WHERE basket_product = ? AND basket_user = ?';
        $stmt = $database->prepare($query);
        $stmt->execute([$_POST['cartIdRemove'], $_SESSION['userId']]);
    }

    header('Refresh: 0');
}
?>

<main>
    <!-- Cart -->
    <section id="cart" class="container">
        <h2 class="section-title">Корзина</h2>
        <?php foreach ($products as $product): ?>
            <div class="cart-item">
                <img src="<?= $product['product_img'] ?>" alt="<?= $product['product_title'] ?>"
                    style="width:80px;height:80px;object-fit:cover;border-radius:6px">
                <div style="flex:1">
                    <p><?= $product['product_title'] ?></p>
                    <small>₽ <?= $product['product_price'] ?> × <?= $product['basket_count'] ?></small>
                </div>
                <div style="display: flex;align-items: center;gap: 10px;">
                    <form method="post"><input type="hidden" value="<?= $product['product_id'] ?>"
                            name="cartIdRemove"><button onclick="pageScrollSet();" class="btn">-</button></form>
                    <p><?= $product['basket_count'] ?></p>
                    <form method="post"> <input type="hidden" value="<?= $product['product_id'] ?>" name="cartIdAdd">
                        <button onclick="pageScrollSet();" class="btn">+</button>
                    </form>
                </div>
                <?php $sum += (int) str_replace(' ', '', $product['product_price']) * $product['basket_count'] ?>
                <?
                $price = (int) str_replace(' ', '', $product['product_price']) * $product['basket_count'];
                ?>
                <?
                $price = substr_replace($price, " ", -3, 0);
                $price = substr_replace($price, " ", -7, 0);
                ?>
                <strong>₽ <?= $price ?></strong>
            </div>
        <?php endforeach; ?>

        <?
        $sum = substr_replace($sum, " ", -3, 0);
        $sum = substr_replace($sum, " ", -7, 0);
        ?>
        <p class="cart-summary">Итого: <?= substr_replace($sum, " ", -3, 0); ?></p>
        <div style="text-align:right">
            <button class="btn">Оформить заказ</button>
        </div>
    </section>
</main>

<script>
    //functions for scroll page 
    function pageScrollSet() {
        localStorage.setItem('scrollPage', pageYOffset);
    }

    document.addEventListener('DOMContentLoaded', function () {
        const all = document.querySelector('*');
        all.style.scrollBehavior = 'auto';
        window.scrollTo(0, localStorage.getItem('scrollPage'));
        all.style.scrollBehavior = 'smooth';
        localStorage.setItem('scrollPage', 0);
    });

</script>