<?
if (session_status()) {
    session_start();
}
include_once 'database/connection.php';
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyShop – современный интернет‑магазин</title>
    <link rel="stylesheet" href="assets/style.css">
</head>

<body>
    <!-- header -->
    <? include_once 'header.php'; ?>
    <!-- header -->

    <!-- main -->
    <?
    if (isset($_GET['page'])) {
        $url = $_GET['page'] . '.php';
        if (file_exists($url)) {
            if (($_GET['page'] == 'admin' || $_GET['page'] == 'create-category' || $_GET['page'] == 'create-product' || $_GET['page'] == 'delete-category' || $_GET['page'] == 'delete-product' || $_GET['page'] == 'edit-category' || $_GET['page'] == 'edit-product') && ((isset($_SESSION['userStat']) && $_SESSION['userStat'] == false) || !isset($_SESSION['userStat']))) {
                include_once '403.php';
            } else if (($_GET['page'] == 'login' || $_GET['page'] == 'register') && (isset($_SESSION['userStat']) && $_SESSION['userStat'] == false)) {
                include_once '403.php';
            } else if (!($_GET['page'] == 'login' || $_GET['page'] == 'register' || $_GET['page'] == 'main') && !isset($_SESSION['userStat'])) {
                include_once '403.php';
            } else {
                include_once $url;
            }
        } else {
            include_once '404.php';
        }
    } else {
        include_once 'main.php';
    }
    ?>
    <!-- main -->

    <!-- footer -->
    <? include_once 'footer.php'; ?>
    <!-- footer -->
</body>

</html>