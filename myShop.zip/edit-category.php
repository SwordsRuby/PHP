<?
$query = 'SELECT * FROM categories WHERE category_id = ?';
$stmt = $database->prepare($query);
$stmt->execute([$_GET['id']]);
$category = $stmt->fetch();

if (!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']) || !$category) {
    die('Категории по данному id не существует');
}
?>

<?
if (isset($_POST['titleUpdate'])) {
    $query = "UPDATE `categories` SET `category_title`=? WHERE category_id = ?";
    $stmt = $database->prepare($query);
    $stmt->execute([$_POST['titleUpdate'], $_GET['id']]);

    header('Location: ?page=admin');
}
?>

<main>
    <section id="categories" class="container">
        <h2 class="section-title">Управление категориями</h2>
        <div class="form-row">
            <form method="post" style="flex:1">
                <h3 style="margin:.5rem 0">Редактировать категорию</h3>
                <input name="titleUpdate" type="text" placeholder="Новое название" value="<?= $category['category_title'] ?>" required>
                <button class="btn" type="submit">Обновить категорию</button>
            </form>
        </div>
    </section>
</main>