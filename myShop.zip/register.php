<? $flag = true; ?>

<main>
    <!-- Registration -->
    <section id="register" class="container">
        <h2 class="section-title">Регистрация</h2>
        <form method="post">
            <div class="form-row">
                <input value="<?= isset($_POST['name']) ? $_POST['name'] : '' ?>" type="text" placeholder="Имя" name="name" required>
                <input value="<?= isset($_POST['surname']) ? $_POST['surname'] : '' ?>" type="text" placeholder="Фамилия" name="surname" required>
            </div>

            <input value="<?= isset($_POST['login']) ? $_POST['login'] : '' ?>" name="login" type="text" placeholder="Логин" required>

            <div class="form-row">
                <input value="<?= isset($_POST['password']) ? $_POST['password'] : '' ?>" name="password" type="password" placeholder="Пароль" required>
                <input value="<?= isset($_POST['passwordRepeat']) ? $_POST['passwordRepeat'] : '' ?>" name="passwordRepeat" type="password" placeholder="Повторите пароль" required>
            </div>
            <? if (isset($_POST['password']) && !empty($_POST['password']) && mb_strlen($_POST['password']) < 6): ?>
                <? $flag = false; ?>
                <p class="error">Пароль должен состоять больше чем из 8 символов</p>
            <? endif; ?>
            <? if (isset($_POST['password']) && !empty($_POST['password']) && $flag && $_POST['password'] != $_POST['passwordRepeat']): ?>
                <? $flag = false; ?>
                <p class="error">Пароли не совпадают</p>
            <? endif; ?>

            <? if ($flag): ?>
                <?
                if (isset($_POST['name'])) {
                    $query = 'SELECT * FROM user WHERE user_login = ?';
                    $stmt = $database->prepare($query);
                    $stmt->execute([$_POST['login']]);
                    $result = $stmt->fetch();

                    if ($result) {
                        $flag = false;
                        echo '<p class="error">Пользователь с таким логином уже существует</p>';
                    }
                }
                ?>
            <? endif; ?>
            <button class="btn" type="submit">Зарегистрироваться</button>
        </form>
    </section>
</main>

<?
if (isset($_POST['login']) && $flag) {
    $query = "INSERT INTO user (user_login, user_password, user_stat, user_name, user_surname) VALUES (?, ?, 0, ?, ?);";
    $stmt = $database->prepare($query);
    $stmt->execute([$_POST['login'], password_hash($_POST['password'], PASSWORD_DEFAULT), $_POST['name'], $_POST['surname']]);

    header('Location: ?page=main');
}
?>