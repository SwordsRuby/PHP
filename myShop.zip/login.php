<? $flag = true; ?>

<main>
  <!-- Login -->
  <section id="login" class="container">
    <h2 class="section-title">Авторизация</h2>
    <form method="post">
      <input value="<?= isset($_POST['login']) ? $_POST['login'] : '' ?>" name="login" type="text" placeholder="Логин">
      <? if (isset($_POST['login']) && empty($_POST['login'])): ?>
        <? $flag = false; ?>
        <p class="error">Пустое поле логин</p>
      <? endif; ?>
      <input value="<?= isset($_POST['password']) ? $_POST['password'] : '' ?>" name="password" type="password" placeholder="Пароль">
      <? if (isset($_POST['password']) && empty($_POST['password'])): ?>
        <? $flag = false; ?>
        <p class="error">Пустое поле пароль</p>
      <? endif; ?>

      <? if ($flag): ?>
        <?
        if (isset($_POST['login'])) {
          $query = 'SELECT * FROM user WHERE user_login = ?';
          $stmt = $database->prepare($query);
          $stmt->execute([$_POST['login']]);
          $result = $stmt->fetch();

          if (!$result || (isset($result['user_password']) && !password_verify($_POST['password'], $result['user_password']))) {
            $flag = false;
            echo '<p class="error">Неверный логин или пароль</p>';
          }
        }
        ?>
      <? endif; ?>
      <button class="btn" type="submit">Войти</button>
    </form>
  </section>
</main>

<?
if (isset($_POST['login']) && $flag) {
  $_SESSION['userLogin'] = $result['user_login'];
  $_SESSION['userId'] = $result['user_id'];

  if ($result['user_stat'] == 1) {
    $_SESSION['userStat'] = true;
  } else {
    $_SESSION['userStat'] = false;
  }

  header('Location: ?page=main');
}
?>