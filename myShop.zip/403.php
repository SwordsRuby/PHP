<main class="page-error">
    <h1>403</h1>
    <a href="?page=main">На главную</a>
</main>