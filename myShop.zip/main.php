<?
if (isset($_GET['action']) && $_GET['action'] == 'exit') {
    unset($_SESSION['userStat']);
    unset($_SESSION['userLogin']);
    header('Location: ?page=main');
}
?>

<?
$query = "SELECT * FROM categories";
$stmt = $database->prepare($query);
$stmt->execute();
$categories = $stmt->fetchAll();
?>

<?
$query = "SELECT * FROM products WHERE product_title LIKE '%'";

if (isset($_GET['category']) && !empty($_GET['category']) && is_numeric($_GET['category'])) {
    $query .= ' AND product_category = :category';
}
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $query .= ' AND product_title LIKE :search';
}

$stmt = $database->prepare($query);
if (isset($_GET['category']) && !empty($_GET['category']) && is_numeric($_GET['category'])) {
    $stmt->bindParam(':category', $_GET['category']);
}
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = '%' . $_GET['search'] . '%';
    $stmt->bindParam(':search', $search);
}
$stmt->execute();
$products = $stmt->fetchAll();
?>

<main>

    <!-- Hero / Home -->
    <section id="home" class="hero">
        <div>
            <h2>Новые гаджеты уже в продаже!</h2>
            <a href="#catalog" class="btn">Перейти к покупкам</a>
        </div>
    </section>

    <!-- Catalog -->
    <section id="catalog" class="container">
        <h2 class="section-title">Каталог электроники</h2>
        <form method="get" class="form-row" style="margin-bottom:1.5rem">
            <input onblur="this.form.submit();" ondragenter="this.form.submit();"
                value="<?= isset($_GET['search']) ? $_GET['search'] : '' ?>" name="search" type="search"
                placeholder="Поиск по товарам…">
            <select name="category" onchange="this.form.submit();">
                <option value="0">Все категории</option>
                <? foreach ($categories as $category): ?>
                    <option <?= (isset($_GET['category']) && $_GET['category'] == $category['category_id']) ? 'selected' : '' ?> value="<?= $category['category_id'] ?>"><?= $category['category_title'] ?></option>
                <? endforeach; ?>
            </select>
        </form>
        <div class="product-grid">
            <? foreach ($products as $product): ?>
                <div class="card">
                    <a class="card-link"
                        href="?<?= isset($_SESSION['userStat']) ? 'page=show&id=' . $product['product_id'] : 'page=login' ?>"></a>
                    <img src="<?= $product['product_img'] ?>" alt="<?= $product['product_title'] ?>"
                        style="height: 200px;width: 100%;object-fit: cover;">
                    <div class="card-body">
                        <h3><?= $product['product_title'] ?></h3>
                        <p class="price">₽ <?= $product['product_price'] ?></p>
                        <? if (isset($_SESSION['userId'])): ?>
                            <? $query = 'SELECT * FROM basket WHERE basket_product = ? AND basket_user = ?';
                            $stmt = $database->prepare($query);
                            $stmt->execute([$product['product_id'], $_SESSION['userId']]);
                            $inBasket = $stmt->fetch();
                            ?>
                            <form data-page="<?= $inBasket ? 'remove' : 'add' ?>" onsubmit="cart(this, event);" method="post"
                                class="cartForm">
                                <? if ($inBasket): ?>
                                    <a href="?page=cart" class="btn btn-outline btn-card">Добавленно!</a>
                                <? else: ?>
                                    <input type="hidden" name="cartIdAdd" value="<?= $product['product_id'] ?>">
                                    <button class="btn btn-outline btn-card">В корзину</button>
                                <? endif; ?>
                            </form>
                        <?php else: ?>
                            <a href="?page=login" class="btn btn-outline btn-card">В корзину</a>
                        <? endif; ?>
                    </div>
                </div>
            <? endforeach; ?>
        </div>
    </section>

    <script>
        function cart(el, event) {
            event.preventDefault();
            try {
                fetch("cart-action.php", {
                    method: 'POST',
                    credentials: 'same-origin',
                    body: new FormData(el),
                })
            } catch (error) {
                console.log(error);
            }

            el.innerHTML = '<a href="?page=cart" class="btn btn-outline btn-card">Добавленно!</a>'
        }
    </script>
</main>