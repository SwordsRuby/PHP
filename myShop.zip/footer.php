<footer style="background:#fff;padding:1.5rem 0;text-align:center;margin-top:3rem;border-top:1px solid #e4e4e4">
    &copy; 2025 MyShop. Все права защищены.
</footer>