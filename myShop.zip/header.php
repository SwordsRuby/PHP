<header>
    <div class="container nav">
        <h1>MyShop</h1>
        <nav class="nav-links">
            <? if ((isset($_SESSION['userStat']) && $_SESSION['userStat'] == true) || !isset($_SESSION['userStat'])): ?>
                <a href="?page=register">Регистрация</a>
                <a href="?page=login">Авторизация</a>
            <? endif; ?>
            <a href="?page=main">Главная</a>
            <? if (isset($_SESSION['userStat'])): ?>
                <a href="?page=cart">Корзина</a>
                <a href="?page=profile">Профиль</a>
                <a href="?page=main&action=exit">Выйти</a>
            <? endif; ?>
            <? if (isset($_SESSION['userStat']) && $_SESSION['userStat'] == true): ?>
                <a href="?page=admin">Админ</a>
            <? endif; ?>
        </nav>
    </div>
</header>