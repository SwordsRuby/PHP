<?
$query = 'SELECT * FROM products JOIN categories ON product_category = category_id WHERE product_id = ?';
$stmt = $database->prepare($query);
$stmt->execute([$_GET['id']]);
$product = $stmt->fetch();

if (!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']) || !$product) {
    die('Товара по данному id не существует');
}
?>

<main>
    <section id="product" class="container">
        <div class="product-view">
            <img src="<?= $product['product_img'] ?>"
                alt="Футболка Basic">
            <div class="product-info">
                <h1><span>Название: </span><?= $product['product_title'] ?></h1>
                <p class="price"><span>Цена: </span>₽ <?= $product['product_price'] ?></p>
                <br>
                <p><span style="font-weight: bold">Категория: </span><?= $product['category_title'] ?></p>
                <br>
                <p><span>Описание: </span><?= $product['product_description'] ?></p>
                <br>
                <div style="display: flex; gap: 10px">
                    <form action="?page=cart" method="post" style="width: 100%">
                        <button class="btn" style="padding: 15px 0px;">Добавить в корзину</button>
                    </form>
                    <? if (isset($_SESSION['userStat']) && $_SESSION['userStat'] == true): ?>
                        <a href="?page=edit-product&id=<?= $_GET['id'] ?>"
                            style="background: var(--primary);color: #fff;width: 100%;text-align: center;padding: .6rem 1.4rem;border: none;border-radius: 4px;">Редактировать</a>
                        <a href="?page=delete-product&id=<?= $_GET['id'] ?>"
                            style="background: var(--primary);color: #fff;width: 100%;padding: .6rem 1.4rem;text-align: center;border: none;border-radius: 4px;">Удалить</a>
                    <? endif; ?>
                </div>
            </div>
        </div>
    </section>
</main>