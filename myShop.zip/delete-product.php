<?
$query = 'SELECT * FROM products JOIN categories ON product_category = category_id WHERE product_id = ?';
$stmt = $database->prepare($query);
$stmt->execute([$_GET['id']]);
$product = $stmt->fetch();

if (!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']) || !$product) {
    die('Товара по данному id не существует');
}
?>

<?
if (isset($_POST['delete'])) {
    unlink(trim($product['product_img'], '/'));
    $query = 'DELETE FROM products WHERE product_id = ?';
    $stmt = $database->prepare($query);
    $stmt->execute([$_GET['id']]);
    header('Location: ?page=admin');
}
?>

<main>
    <!-- Delete Product -->
    <section id="delete-product" class="container">
        <h2 class="section-title">Удаление продукта "<?= $product['product_title'] ?>"</h2>
        <form method="post" style="display: flex;gap: 1.5rem;">
            <a href="?page=show&id=<?= $_GET['id'] ?>" class="btn">Отмена</a>
            <input type="hidden" name="delete">
            <button class="btn" style="background:var(--accent)">Удалить продукт</button>
        </form>
    </section>
</main>