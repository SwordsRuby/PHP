<?
$query = 'SELECT * FROM products JOIN categories ON product_category = category_id WHERE product_id = ?';
$stmt = $database->prepare($query);
$stmt->execute([$_GET['id']]);
$product = $stmt->fetch();

$query = "SELECT * FROM categories";
$stmt = $database->prepare($query);
$stmt->execute();
$categories = $stmt->fetchAll();

if (!isset($_GET['id']) || empty($_GET['id']) || !is_numeric($_GET['id']) || !$product) {
    die('Товара по данному id не существует');
}
?>

<?
if (isset($_POST['titleUpdate'])) {
    $img = $product['product_img'];
    $query = "UPDATE `products` SET `product_title`=?,`product_img`=?,`product_price`=?,`product_description`=?,`product_category`=? WHERE product_id = ?";
    $stmt = $database->prepare($query);
    if (!empty($_FILES['imgUpdate']['tmp_name'])) {
        $img = 'public/img/' . uniqid('img_') . $_FILES['imgUpdate']['name'];
        move_uploaded_file($_FILES['imgUpdate']['tmp_name'], $img);
        $img = '/' . $img;
    }
    $stmt->execute([$_POST['titleUpdate'], $img, $_POST['priceUpdate'], $_POST['descriptionUpdate'], $_POST['categoryUpdate'], $_GET['id']]);

    header('Location: ?page=main');
}
?>

<main>
    <!-- Edit Product -->
    <section id="edit-product" class="container">
        <h2 class="section-title">Редактирование продукта</h2>
        <form enctype="multipart/form-data" method="post">
            <input required name="titleUpdate" type="text" placeholder="Название" value="<?= $product['product_title'] ?>">
            <textarea required name="descriptionUpdate"><?= $product['product_description'] ?></textarea>
            <input required name="priceUpdate" type="text" value="<?= $product['product_price'] ?>">
            <select required name="categoryUpdate">
                <? foreach ($categories as $category): ?>
                    <option <?= $product['product_category'] == $category['category_id'] ? 'selected' : '' ?> value="<?= $category['category_id'] ?>"><?= $category['category_title'] ?></option>
                <? endforeach; ?>
            </select>
            <input type="hidden" value="<?= $product['product_img'] ?>" name="imgString">
            <input name="imgUpdate" type="file" accept="image/*">
            <button class="btn" type="submit">Обновить продукт</button>
        </form>
    </section>
</main>