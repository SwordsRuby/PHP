<?php
require_once 'database/connection.php';

if (session_status()) {
    session_start();
}

if (isset($_POST['cartIdAdd'])) {
    $query = 'SELECT * FROM basket WHERE basket_product = ? AND basket_user = ?';
    $stmt = $database->prepare($query);
    $stmt->execute([$_POST['cartIdAdd'], $_SESSION['userId']]);
    $inBasket = $stmt->fetch();

    $query = 'SELECT * FROM products WHERE product_id = ?';
    $stmt = $database->prepare($query);
    $stmt->execute([$_POST['cartIdAdd']]);
    $product = $stmt->fetch();

    if ($inBasket && $product) {
        $query = 'UPDATE basket SET basket_count = basket_count + 1 WHERE basket_product = ? AND basket_user = ?';
        $stmt = $database->prepare($query);
        $stmt->execute([$_POST['cartIdAdd'], $_SESSION['userId']]);
    } else if ($product) {
        $query = 'INSERT INTO basket (basket_product, basket_user, basket_count) VALUES (?, ?, ?)';
        $stmt = $database->prepare($query);
        $stmt->execute([$_POST['cartIdAdd'], $_SESSION['userId'], 1]);
    }
}

if (isset($_POST['cartIdRemove'])) {
    $query = 'SELECT * FROM basket WHERE basket_product = ? AND basket_user = ?';
    $stmt = $database->prepare($query);
    $stmt->execute([$_POST['cartIdRemove'], $_SESSION['userId']]);
    $inBasket = $stmt->fetch();

    $query = 'SELECT * FROM products WHERE product_id = ?';
    $stmt = $database->prepare($query);
    $stmt->execute([$_POST['cartIdRemove']]);
    $product = $stmt->fetch();

    if ($inBasket && $product && $inBasket['basket_count'] != 1) {
        $query = 'UPDATE basket SET basket_count = basket_count - 1 WHERE basket_product = ? AND basket_user = ?';
        $stmt = $database->prepare($query);
        $stmt->execute([$_POST['cartIdRemove'], $_SESSION['userId']]);
    } else if ($inBasket && $product && $inBasket['basket_count'] == 1) {
        $query = 'DELETE FROM basket WHERE basket_product = ? AND basket_user = ?';
        $stmt = $database->prepare($query);
        $stmt->execute([$_POST['cartIdRemove'], $_SESSION['userId']]);
    }
}
?>