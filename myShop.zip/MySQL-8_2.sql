-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: MySQL-8.2
-- Generation Time: Apr 27, 2025 at 10:13 PM
-- Server version: 8.2.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `MyShop`
--
CREATE DATABASE IF NOT EXISTS `MyShop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `MyShop`;

-- --------------------------------------------------------

--
-- Table structure for table `basket`
--

CREATE TABLE `basket` (
  `basket_user` int NOT NULL,
  `basket_product` int NOT NULL,
  `basket_count` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `basket`
--

INSERT INTO `basket` (`basket_user`, `basket_product`, `basket_count`) VALUES
(2, 1, 1),
(2, 7, 2);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int NOT NULL,
  `category_title` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_title`) VALUES
(1, 'Смартфоны'),
(2, 'Аксессуары к гаджетам'),
(3, 'Ноутбуки'),
(4, 'Планшеты'),
(5, 'Часы'),
(6, 'Умная техника');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int NOT NULL,
  `product_title` varchar(300) NOT NULL,
  `product_img` varchar(10000) NOT NULL,
  `product_price` varchar(100) NOT NULL,
  `product_description` varchar(3000) NOT NULL,
  `product_category` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_title`, `product_img`, `product_price`, `product_description`, `product_category`) VALUES
(1, 'Смартфон Galaxy S24', './assets/images/b21ddd979b8fc432b15e4ae3f9be9d76f4b25d258e4632490cfd1506ee4ec8ec.JPEG', '89 990', 'Galaxy S24 – это флагманский смартфон с мощным процессором, превосходной камерой и ярким AMOLED-дисплеем. Он идеально подходит для тех, кто ценит высокую производительность, стильный дизайн и продвинутые функции съемки. Отличный выбор для ежедневного использования и активного образа жизни.', 1),
(2, 'MacBook Air M3', './assets/images/60827415a891452fc7323fd6fbaf8945b7f8df9e1bd05e2a2ee0fa2afe85e753.JPEG', '139 990', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 3),
(3, 'Sony WH-1000XM5', './assets/images/562d39bbdcc771b0ef92bbb72010c7ec941074b5e8a8dae07376a17bc00208cb.JPEG', '29 990', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 2),
(7, 'Apple Watch SE', '/public/img/img_680bd52c6b17b78d3df10f924f9db36b8d11f749d8027366c666da05ea89f5bd4e8a6abfe8e95.JPEG', '49 456', 'Easy ways to stay connected. Motivating fitness metrics. Innovative health and safety features. Fresh band colors. Apple Watch SE is packed with features at a feel-good price.', 5),
(11, 'Galaxy a32', '/public/img/img_680bd8f869422b21ddd979b8fc432b15e4ae3f9be9d76f4b25d258e4632490cfd1506ee4ec8ec.JPEG', '24 456', 'lorem...', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int NOT NULL,
  `user_login` varchar(100) NOT NULL,
  `user_password` varchar(3000) NOT NULL,
  `user_stat` tinyint(1) NOT NULL,
  `user_name` varchar(300) NOT NULL,
  `user_surname` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_login`, `user_password`, `user_stat`, `user_name`, `user_surname`) VALUES
(2, 'C', '$2y$10$BWKY16LuPFwbNw5sMp2./OfZtMp0Nuef09XKSmFn7tKlOXmbs4jF.', 0, 'Z', 'X'),
(3, 'root', '$2y$10$gRYNNztZZmFizF9sJYfyU.Un7t3BMUFWmeVTvEZcBVf61GwyfUi3q', 1, '.', '.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `basket`
--
ALTER TABLE `basket`
  ADD PRIMARY KEY (`basket_user`,`basket_product`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
