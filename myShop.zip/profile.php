<main>
    <!-- Профиль -->
    <section id="profile" class="container">
        <h2 class="section-title">Профиль пользователя</h2>
        <p><strong>Имя:</strong> Иван Иванов</p>
        <p><strong>Логин:</strong> ivan</p>

        <h3 style="margin:2rem 0 1rem">История заказов</h3>

        <div class="order-block">
            <div class="order-header">
                <div>Заказ №122 от 15.03.2025</div>
                <div><span style="font-weight: 300">Статус: </span>Выполнено</div>
            </div>
            <p><strong>Общая сумма:</strong> ₽5 700</p>
            <table class="order-products">
                <thead>
                    <tr>
                        <th>Название</th>
                        <th>Цена</th>
                        <th>Количество</th>
                        <th>Сумма</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Смартфон</td>
                        <td>₽1 200</td>
                        <td>1</td>
                        <td>₽1 200</td>
                    </tr>
                    <tr>
                        <td>Смартфон</td>
                        <td>₽4 500</td>
                        <td>1</td>
                        <td>₽4 500</td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="order-block">
            <div class="order-header">
                <div>Заказ №122 от 15.03.2025</div>
                <div><span style="font-weight: 300">Статус: </span>Выполнено</div>
            </div>
            <p><strong>Общая сумма:</strong> ₽1 200</p>
            <table class="order-products">
                <thead>
                    <tr>
                        <th>Название</th>
                        <th>Цена</th>
                        <th>Количество</th>
                        <th>Сумма</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Смартфон</td>
                        <td>₽1 200</td>
                        <td>1</td>
                        <td>₽1 200</td>
                    </tr>
                </tbody>
            </table>
        </div>

    </section>
</main>