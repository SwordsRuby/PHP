<?
if (isset($_POST['categoryAdd'])) {
    $query = "INSERT INTO `categories`(`category_title`) VALUES (?)";
    $stmt = $database->prepare($query);

    $stmt->execute([$_POST['categoryAdd']]);

    header('Location: ?page=admin');
}
?>

<main>
    <section id="categories" class="container">
        <h2 class="section-title">Управление категориями</h2>
        <div class="form-row">
            <form method="post" style="flex:1">
                <h3 style="margin:.5rem 0">Создать категорию</h3>
                <input name="categoryAdd" type="text" placeholder="Название" required>
                <button class="btn" type="submit">Создать</button>
            </form>
        </div>
    </section>
</main>