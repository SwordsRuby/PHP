<main class="page-error">
    <h1>404</h1>
    <a href="?page=main">На главную</a>
</main>