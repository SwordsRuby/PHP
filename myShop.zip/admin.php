<?
$query = "SELECT * FROM categories";
$stmt = $database->prepare($query);
$stmt->execute();
$categories = $stmt->fetchAll();

$query = "SELECT * FROM products JOIN categories ON product_category = category_id";
$stmt = $database->prepare($query);
$stmt->execute();
$products = $stmt->fetchAll();
?>

<main>

    <!-- Admin Panel -->
    <section id="admin" class="container">
        <h2 class="section-title">Админ‑панель</h2>
        <div style="margin-bottom: 20px;">
            <a href="?page=create-category" class="btn btn-outline">Создать категорию</a>
            <a href="?page=create-product" class="btn btn-outline">Создать продукт</a>
        </div>
        <div>
            <div>
                <h3>Категории</h3>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Название</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <? foreach ($categories as $category): ?>
                            <tr>
                                <td><?= $category['category_id'] ?></td>
                                <td><?= $category['category_title'] ?></td>
                                <td>
                                    <a href="?page=edit-category&id=<?= $category['category_id'] ?>"
                                        class="btn btn-outline">Изменить</a>
                                    <a href="?page=delete-category&id=<?= $category['category_id'] ?>" class="btn"
                                        style="background:var(--accent)">Удалить</a>
                                </td>
                            </tr>
                        <? endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div>
                <h3>Продукты</h3>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Название</th>
                            <th>Цена</th>
                            <th>Категория</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <? foreach ($products as $product): ?>
                            <tr>
                                <td><?= $product['product_id'] ?></td>
                                <td><?= $product['product_title'] ?></td>
                                <td>₽ <?= $product['product_price'] ?></td>
                                <td><?= $product['category_title'] ?></td>
                                <td>
                                    <a href="?page=edit-product&id=<?= $product['product_id'] ?>"
                                        class="btn btn-outline">Изменить</a>
                                    <a href="?page=delete-product&id=<?= $product['product_id'] ?>" class="btn"
                                        style="background:var(--accent)">Удалить</a>
                                </td>
                            </tr>
                        <? endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div>
                <h3>Заказы</h3>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Фио заказчика</th>
                            <th>Общая цена</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>10</td>
                            <td>Альберт Рашитов</td>
                            <td>₽1 200</td>
                            <td>Выполнено</td>
                            <td>
                                <form action="" method="post"><select name="" id="">
                                        <option value="">Выполнено</option>
                                        <option value="">Отказано</option>
                                    </select>
                                    <input type="submit" class="btn" value="Изменить">

                                </form>
                            </td>
                        </tr>
                        <tr>
                            <td>10</td>
                            <td>Альберт Рашитов</td>
                            <td>₽1 200</td>
                            <td>Выполнено</td>
                            <td>
                                <form action="" method="post"><select name="">
                                        <option value="">Выполнено</option>
                                        <option value="">Отказано</option>
                                    </select>
                                    <input type="submit" class="btn" value="Изменить">

                                </form>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</main>