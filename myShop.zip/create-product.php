<?
$query = "SELECT * FROM categories";
$stmt = $database->prepare($query);
$stmt->execute();
$categories = $stmt->fetchAll();
?>

<?
if (isset($_POST['titleAdd'])) {
    $query = "INSERT INTO `products`(`product_title`, `product_img`, `product_price`, `product_description`, `product_category`) VALUES (?, ?, ?, ?, ?)";
    $stmt = $database->prepare($query);

    $img = 'public/img/' . uniqid('img_') . $_FILES['imgAdd']['name'];
    move_uploaded_file($_FILES['imgAdd']['tmp_name'], $img);
    $img = '/' . $img;

    $stmt->execute([$_POST['titleAdd'], $img, $_POST['priceAdd'], $_POST['descriptionAdd'], $_POST['categoryAdd']]);

    header('Location: ?page=admin');
}
?>

<main>
    <!-- Create Product -->
    <section id="create-product" class="container">
        <h2 class="section-title">Создание продукта</h2>
        <form method="post" enctype="multipart/form-data">
            <input name="titleAdd" type="text" placeholder="Название" required>
            <textarea name="descriptionAdd" placeholder="Описание" required></textarea>
            <input name="priceAdd" type="text" placeholder="Цена" required>
            <select name="categoryAdd">
                <? foreach ($categories as $category): ?>
                    <option value="<?= $category['category_id'] ?>"><?= $category['category_title'] ?></option>
                <? endforeach; ?>
            </select>
            <input name="imgAdd" type="file" accept="image/*" required>
            <button class="btn" type="submit">Создать продукт</button>
        </form>
    </section>
</main>