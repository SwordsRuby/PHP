<?
try {
    $database = new PDO('mysql:host=MySQL-8.2;dbname=MyShop;charset=utf8;', 'root', '1234');
} catch (PDOException $e) {
    die($e->getMessage());
}
