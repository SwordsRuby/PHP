<? $flag = true; ?>
<main>
    <div class="out_wrapper">
        <form method="post">
            <h1>Авторизация</h1>
            <? if (isset($_POST['authMail']) && (empty($_POST['authMail']) || empty($_POST['authPassword']))): ?>
                <p class="error">Заполните все поля</p>
            <? endif; ?>
            <input value="<?= isset($_POST['authMail']) ? $_POST['authMail'] : '' ?>" type="text" name="authMail" placeholder="Почта">
            <?
            if (isset($_POST['authMail']) && !filter_var($_POST['authMail'], FILTER_VALIDATE_EMAIL)) {
                $flag = false;
                echo '<p class="error">Неверный формат почты</p>';
            }
            ?>
            <input value="<?= isset($_POST['authPassword']) ? $_POST['authPassword'] : '' ?>" type="password" name="authPassword" placeholder="Пароль">
            <?
            if (isset($_POST['authPassword']) && mb_strlen($_POST['authPassword']) < 8) {
                $flag = false;
                echo '<p class="error">Пароль меньше 8 символов</p>';
            }
            ?>
            <input class="form_btn" type="submit" name="" value="Авторизоваться">
        </form>
    </div>
</main>
<?
if (isset($_POST['authMail']) && !empty($_POST['authMail']) && !empty($_POST['authPassword'])) {
    $query = 'SELECT * FROM user WHERE user_mail = :authMail';
    $stmt = $database->prepare($query);
    $stmt->bindParam(':authMail', $_POST['authMail']);
    $stmt->execute();
    $result = $stmt->fetch();

    if (!empty($result) && password_verify($_POST['authPassword'], $result['user_password'])) {
        $_SESSION['userName'] = $result['user_name'];

        if ($result['user_stat'] == 0) {
            $_SESSION['userStat'] = false;
            header('Location: index.php?page=catalog');
        } else {
            $_SESSION['userStat'] = true;
            header('Location: index.php?page=admin');
        }
    } else {
        echo "<script>alert('Неверный логин или пароль')</script>";
    }
}
?>