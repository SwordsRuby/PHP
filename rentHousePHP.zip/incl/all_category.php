<?
if (isset($_GET['delId']) && !empty($_GET['delId']) && is_numeric($_GET['delId'])) {
    $query = 'DELETE FROM category WHERE category_id = :delId';
    $stmt = $database->prepare($query);
    $stmt->bindParam(":delId", $_GET['delId']);
    $stmt->execute();

    $query = 'DELETE FROM product WHERE product_city = :delId';
    $stmt = $database->prepare($query);
    $stmt->bindParam(":delId", $_GET['delId']);
    $stmt->execute();

    header('Location: ?page=all_category');
}

$query = 'SELECT * FROM category';
$stmt = $database->query($query);
$stmt->execute();
$categories = $stmt->fetchAll();
?>

<main>
    <div class="out_wrapper">
        <h1>Все категории</h1>

        <div class="categories_block">
            <? foreach ($categories as $category): ?>
                <div class="product product_basket">
                    <p> <?= $category['category_title'] ?></p>
                    <a onclick="confirm('Хотите удалить категорию?');" href="?page=all_category&delId=<?= $category['category_id'] ?>" class="minus btn_auth">Удалить</a>
                </div>
            <? endforeach; ?>
        </div>
    </div>
    </div>
    </div>
</main>