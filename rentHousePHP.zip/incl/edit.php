<?
$query = "SELECT * FROM product LEFT JOIN category ON product.product_city = category.category_id WHERE product_id = :editId";
$stmt = $database->prepare($query);
$stmt->bindParam(':editId', $_GET['editId']);
$stmt->execute();
$result = $stmt->fetch();

if (empty($result) || !isset($_GET['editId']) || empty($_GET['editId'])) {
    die('Продукта не существует');
}

$query = 'SELECT * FROM category';
$stmt = $database->query($query);
$stmt->execute();
$categories = $stmt->fetchAll();

if (isset($_POST['editName']) && !empty($_POST['editName']) && !empty($_POST['editCity']) && !empty($_POST['editPrice']) && !empty($_POST['editDescription'])) {
    $query = "UPDATE product SET product_title = :editName, product_city = :editCity, product_price = :editPrice, product_description = :editDescription, product_image = :editImage WHERE product_id = :editId";
    $stmt = $database->prepare($query);
    $stmt->bindParam(':editId', $_GET['editId']);
    $stmt->bindParam(':editName', $_POST['editName']);
    $stmt->bindParam(':editCity', $_POST['editCity']);
    $stmt->bindParam(':editPrice', $_POST['editPrice']);
    $stmt->bindParam(':editDescription', $_POST['editDescription']);
    if (!empty($_FILES['editImage']['tmp_name'])) {
        $imgName = '/public/img/' . uniqid('img_') . '.' . pathinfo($_FILES['editImage']['name'], PATHINFO_EXTENSION);

        if (move_uploaded_file($_FILES['editImage']['tmp_name'],  dirname(__FILE__) . '/..' . $imgName)) {
            $stmt->bindParam(':editImage', $imgName);
        }
    } else {
        $stmt->bindParam(':editImage', $result['product_image']);
    }
    $stmt->execute();

    header('Location: ?page=catalog');
}
?>

<main>
    <div class="out_wrapper">
        <form method="post" enctype="multipart/form-data">
            <h1>Редактировать товар</h1>
            <? if (isset($_POST['editName']) && (empty($_POST['editName']) || empty($_POST['editCity']) || empty($_POST['editPrice']) || empty($_POST['editDescription']))): ?>
                <p class="error">Заполните все поля</p>
            <? endif; ?>
            <input value="<?= $result['product_title'] ?>" type="text" name="editName" placeholder="Название">
            <select name="editCity">
                <? foreach ($categories as $category): ?>
                    <option value="<?= $category['category_id'] ?>"><?= $category['category_title'] ?></option>
                <? endforeach; ?>
            </select>
            <input value="<?= $result['product_price'] ?>" type="number" name="editPrice" placeholder="Цена">
            <textarea name="editDescription" placeholder="Описание"><?= $result['product_description'] ?></textarea>
            <input type="file" name="editImage" id="editImage">


            <input class="form_btn" type="submit" value="Редактировать">
        </form>
    </div>
</main>