<?
if (isset($_POST['addCategory']) && !empty($_POST['addCategory'])) {
    $query = 'SELECT * FROM category WHERE category_title = :addCategory';
    $stmt = $database->prepare($query);
    $stmt->bindParam(':addCategory', $_POST['addCategory']);
    $stmt->execute();
    $category = $stmt->fetch();

    if ($category) {
        echo "<script>alert('Такая категория существует')</script>";
    } else {
        $query = "INSERT INTO category (category_title) VALUES (:addCategory)";
        $stmt = $database->prepare($query);
        $stmt->bindParam(':addCategory', $_POST['addCategory']);
        $stmt->execute();

        header('Location: ?page=add_category');
    }
}
?>

<main>
    <div class="out_wrapper">
        <form method="post">
            <h1>Добавить категорию</h1>
            <input type="text" name="addCategory" placeholder="Название">
            <input class="form_btn" type="submit" name="" value="Добавить">
        </form>
    </div>
</main>