<?
$query = 'SELECT * FROM category';
$stmt = $database->query($query);
$stmt->execute();
$categories = $stmt->fetchAll();

if (isset($_POST['addName']) && !empty($_POST['addName']) && !empty($_POST['addCategory']) && !empty($_POST['addPrice']) && !empty($_POST['addDescription']) && !empty($_FILES['addImage']['tmp_name'])) {
    $imgName = '/public/img/' . uniqid('img_') . '.' . pathinfo($_FILES['addImage']['name'], PATHINFO_EXTENSION);

    $query = "INSERT INTO product  (product_title, product_city, product_price, product_description, product_image) VALUES (:addName, :addCategory, :addPrice, :addDescription, :addImage)";
    $stmt = $database->prepare($query);
    $stmt->bindParam(':addName', $_POST['addName']);
    $stmt->bindParam(':addCategory', $_POST['addCategory']);
    $stmt->bindParam(':addPrice', $_POST['addPrice']);
    $stmt->bindParam(':addDescription', $_POST['addDescription']);
    if (move_uploaded_file($_FILES['addImage']['tmp_name'],  dirname(__FILE__) . '/..' . $imgName)) {
        $stmt->bindParam(':addImage', $imgName);
    }
    $stmt->execute();

    header('Location: ?page=catalog');
}
?>


<main>
    <div class="out_wrapper">
        <form method="post" enctype="multipart/form-data">
            <h1>Добавить дом</h1>
            <? if (isset($_POST['addName']) && (empty($_POST['addName']) || empty($_POST['addCategory']) || empty($_POST['addPrice']) || empty($_POST['addDescription']) || empty($_FILES['addImage']['tmp_name']))): ?>
                <p class="error">Заполните все поля</p>
            <? endif; ?>
            <input type="text" name="addName" placeholder="Название">
            <select name="addCategory">
                <? foreach ($categories as $category): ?>
                    <option value="<?= $category['category_id'] ?>"><?= $category['category_title'] ?></option>
                <? endforeach; ?>
            </select>
            <input type="number" name="addPrice" placeholder="Цена">
            <textarea name="addDescription" placeholder="Описание"></textarea>
            <input type="file" name="addImage">


            <input class="form_btn" type="submit" value="Добавить">
        </form>
    </div>
</main>