<main class="page_404">
    <h1>404</h1>
    <a href="index.php">
        На главную
    </a>
</main>