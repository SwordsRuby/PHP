<? $flag = true; ?>

<main>
    <div class="out_wrapper">
        <form method="post">
            <h1>Регистрация</h1>
            <? if (isset($_POST['regName']) && (empty($_POST['regName']) || empty($_POST['regPassword']) || empty($_POST['regSurname']) || empty($_POST['regPasswordRepeat']) || empty($_POST['regMail']))): ?>
                <p class="error">Заполните все поля</p>
            <? endif; ?>
            <input value="<?= isset($_POST['regName']) ? $_POST['regName'] : '' ?>" type="text" name="regName" placeholder="Имя*">
            <input value="<?= isset($_POST['regSurname']) ? $_POST['regSurname'] : '' ?>" type="text" name="regSurname" placeholder="Фамилия*">
            <input value="<?= isset($_POST['regMail']) ? $_POST['regMail'] : '' ?>" type="text" name="regMail" placeholder="Почта*">
            <?
            if (isset($_POST['regMail']) && !filter_var($_POST['regMail'], FILTER_VALIDATE_EMAIL)) {
                $flag = false;
                echo '<p class="error">Неверный формат почты</p>';
            }
            ?>
            <input value="<?= isset($_POST['regPassword']) ? $_POST['regPassword'] : '' ?>" type="password" name="regPassword" placeholder="Пароль*">
            <?
            if (isset($_POST['regPassword']) && mb_strlen($_POST['regPassword']) < 8) {
                $flag = false;
                echo '<p class="error">Пароль меньше 8 символов</p>';
            }
            ?>
            <input value="<?= isset($_POST['regPasswordRepeat']) ? $_POST['regPasswordRepeat'] : '' ?>" type="password" name="regPasswordRepeat" placeholder="Повторите пароль*">
            <?
            if (isset($_POST['regPassword']) && mb_strlen($_POST['regPassword']) >= 8 && $_POST['regPassword'] != $_POST['regPasswordRepeat']) {
                $flag = false;
                echo '<p class="error">Пароли не совпадают</p>';
            }
            ?>

            <input class="form_btn" type="submit" value="Зарегистрироваться">
        </form>
    </div>
</main>

<?
if (isset($_POST['regName']) && !empty($_POST['regName']) && !empty($_POST['regPassword']) && !empty($_POST['regSurname']) && !empty($_POST['regPasswordRepeat']) && !empty($_POST['regMail'])) {
    $query = 'SELECT * FROM user WHERE user_mail = :regMail';
    $stmt = $database->prepare($query);
    $stmt->bindParam(':regMail', $_POST['regMail']);
    $stmt->execute();
    $result = $stmt->fetch();

    if ($result) {
        echo "<script>alert('пользователь c такой почтой существует')</script>";
    } elseif ($flag) {
        $query = 'INSERT INTO `user` (`user_name`, `user_surname`, `user_mail`, `user_password`, `user_stat`) VALUES (:regName, :regSurname, :regMail, :regPassword, 0)';
        $password = password_hash($_POST['regPassword'], PASSWORD_DEFAULT);
        $stmt = $database->prepare($query);
        $stmt->bindParam(':regName', $_POST['regName']);
        $stmt->bindParam(':regSurname', $_POST['regSurname']);
        $stmt->bindParam(':regMail', $_POST['regMail']);
        $stmt->bindParam(':regPassword', $password);
        $stmt->execute();

        header('Location: index.php/?page=authorization');
    }
}
?>