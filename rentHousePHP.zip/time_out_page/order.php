<main>
    <div class="out_wrapper">
        <form action="">
            <h1>Забронировать дом</h1>
            <input type="text" name="" placeholder="Дата заезда">
            <input type="text" name="" placeholder="Дата выезда">
            <input type="text" name="" placeholder="Номер телефона">

            <input class="form_btn" type="submit" name="" value="Забронировать">
        </form>
    </div>
</main>