<?
if (session_status()) {
  session_start();
}
include_once 'database/connection.php';
?>

<!DOCTYPE html>
<html lang="ru">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="/css/style.css" />
  <title>Природный Оазис</title>
  <link rel="icon" type="image/svg" href="/images/logo.svg" />
</head>

<body>
  <!-- header -->
  <? include_once 'incl/header.php'; ?>
  <!-- header -->

  <!-- router -->
  <?
  //default
  if (!isset($_GET['page']) || empty($_GET['page'])) {
    include_once 'incl/catalog.php';
  } elseif (file_exists('incl/' . $_GET['page'] . '.php')) {
    // admin
    if (isset($_SESSION['userStat']) && $_SESSION['userStat'] == true) {
      include_once 'incl/' . $_GET['page'] . '.php';
    }
    // guest
    else if (!isset($_SESSION['userStat']) && (!isset($_GET['page']) || (isset($_GET['page']) && ($_GET['page'] == 'authorization' || $_GET['page'] == 'registration')))) {
      include_once 'incl/' . $_GET['page'] . '.php';
    }
    // authorized user
    else if (isset($_SESSION['userStat']) && $_SESSION['userStat'] == false && (!isset($_GET['page']) || (isset($_GET['page']) && ($_GET['page'] != 'admin' || $_GET['page'] != 'all_category' || $_GET['page'] != 'add_category' || $_GET['page'] != 'add' || $_GET['page'] != 'registration' || $_GET['page'] != 'authorization' || $_GET['page'] != 'edit')))) {
      include_once 'incl/' . $_GET['page'] . '.php';
    }
    // forbidden
    else {
      include_once 'incl/catalog.php';
    }
  } else {
    //404
    include_once 'incl/404.php';
  }
  ?>
  <!-- router -->

  <!-- footer -->
  <? include_once 'incl/footer.php' ?>
  <!-- footer -->
</body>

</html>