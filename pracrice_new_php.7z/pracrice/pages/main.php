<?php

$sql = "SELECT * FROM products";
$products = $database->query("SELECT * FROM products")->fetchAll();

?>

<h1>Главная</h1>

<h4>Каталог товаров:</h4>

<?php if (!empty($products)): ?>
    <?php foreach ($products as $product): ?>
        <div>
            <img src="../uploads/<?= $product['image'] ?>" alt="" style="width: 200;">
            <p>Название: <?= $product['title'] ?></p>
            <p>Описание: <?= $product['description'] ?></p>
            <p>Цена: <?= $product['price'] ?></p>
            <a href="./?page=product&id=<?= $product['id'] ?>">Подробнее</a>
        </div>
    <?php endforeach; ?>
    <br>
<?php else : ?>
    <h6>Товаров не обнаружено</h6>
<?php endif; ?>