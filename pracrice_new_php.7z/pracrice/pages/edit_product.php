<?php
if (empty($_GET['id'])) {
    include('pages/404.php');
    exit;
}

$id = $_GET['id'];
$product = $database->query("SELECT * FROM products WHERE id = $id")->fetch();

if (!$product) {
    include '404.php';
    exit;
}

$errors = [];
$image = $product['image'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (empty($title) || empty($description) || empty($price)) {
        $errors[] = 'Заполните все поля';
    } elseif (strlen($title) < 3 || strlen($description) < 3) {
        $errors[] = 'Запишите больше 3 символов';
    } elseif (!is_numeric($price)) {
        $errors[] = 'цена не число';
    } elseif ($price < 100) {
        $errors[] = 'цена дожна быть больше 100';
    }

    if ($_FILES['image'] && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads/';
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp', 'image/jfif'];
        $maxSize = 1024 * 1024 * 2;

        if (!is_dir($uploadDir)) {
            if (!mkdir($uploadDir, 0755, true)) {
                $errors[] = 'не удалось создать папку';
            }
        }

        if (empty($errors)) {
            if (!in_array($_FILES['image']['type'], $allowedTypes)) {
                $errors[] = 'неверное расширение';
            } elseif ($_FILES['image']['size'] > $maxSize) {
                $errors[] = 'файл слишком большой';
            } else {
                $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
                $newName = uniqid() . '.' . $extension;
                $targetPath = $uploadDir . $newName;

                if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
                    // Delete old image if it exists and is a file (not directory)
                    if (!empty($product['image']) && file_exists($uploadDir . $product['image']) && is_file($uploadDir . $product['image'])) {
                        unlink($uploadDir . $product['image']);
                    }
                    $image = $newName;
                } else {
                    $errors[] = 'изображение не загружено';
                }
            }
        }
    }

    if (empty($errors)) {

        $result = $database->query("UPDATE products SET `title` = '$title', `description` = '$description', `price` = $price, `image` = '$image' WHERE `id` = '$id'");
        header("Location: ./?page=product&id=$id");
        exit;
    }
}
?>

<h1>Редактирование продукта</h1>

<form method="post" enctype="multipart/form-data">
    <input type="text" name="title" placeholder="название" value="<?= htmlspecialchars($product['title'] ?? '') ?>">
    <br>
    <textarea name="description" placeholder="описание"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
    <br>
    <input type="text" name="price" placeholder="цена" value="<?= htmlspecialchars($product['price'] ?? '') ?>">
    <br>
    <input type="file" name="image">
    <?php if (!empty($errors)): ?>
        <?php foreach ($errors as $error): ?>
            <div style="color: indianred;"><?= htmlspecialchars($error) ?></div>
        <?php endforeach; ?>
    <?php endif; ?>
    <input type="submit" value="Сохранить">
</form>