<?php
if (empty($_GET['id'])) {
    include('pages/404.php');
    exit;
}

$id = $_GET['id'];
$product = $database->query("SELECT * FROM products WHERE id = $id")->fetch();

if (!$product) {
    include '404.php';
    exit;
}

?>

<h1>Один продукт</h1>
<img src="../uploads/<?= $product['image'] ?>" alt="" style="width: 200;">
<h2><?= $product['title'] ?></h2>
<p><?= $product['description']  ?></p>
<p><?= $product['price']  ?></p>

<a href="./?page=edit_product&id=<?= $product['id'] ?>">Редактирование</a>
<a href="./?page=delete_product&id=<?= $product['id'] ?>">Удаление</a>