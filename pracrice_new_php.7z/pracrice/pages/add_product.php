<h1>Добавления продукта</h1>

<?php
$errors = [];
$image = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    if (empty($title) || empty($description) || empty($price)) {
        $errors[] = 'Заполните все поля';
    } elseif (strlen($title) < 3 || strlen($description) < 3) {
        $errors[] = 'Запишите больше 3 символов';
    } elseif (!is_numeric($price)) {
        $errors[] = 'цена не число';
    } elseif ($price < 100) {
        $errors[] = 'цена дожна быть больше 100';
    }

    if ($_FILES['image']  && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads';
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp', 'image/jfif'];
        $maxSize = 1024 * 1024 * 2;


        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
            $errors[] = 'не удалось создать папку';
        } elseif (!in_array($_FILES['image']['type'], $allowedTypes)) {
            $errors[] = 'неверное расширение';
        } elseif ($_FILES['image']['size'] > $maxSize) {
            $errors[] = 'файл слишком большой';
        } else {
            $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $newName = uniqid() . '.' . $extension;
            $dir = $uploadDir . '/' . $newName;
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $dir)) {
                $errors[] = 'изображение не загружено';
            }
            $image = $newName;
        }
    }

    if (empty($errors)) {
        $result = $database->query("INSERT INTO products (title, description, price, image) VALUES ('$title', '$description', $price, '$image')");
        header('Location: ./');
    }
}
?>

<form action="" method="post" enctype="multipart/form-data">
    <input type="text" name="title" placeholder="название" value="<?= $_POST['title'] ?? '' ?>">
    <br>
    <textarea name="description" id="" placeholder="описание"><?= $_POST['description'] ?? '' ?></textarea>
    <br>
    <input type="text" name="price" placeholder="цена" value="<?= $_POST['price'] ?? '' ?>">
    <br>
    <input type="file" name="image">
    <br>
    <?php
    if (!empty($errors)): ?>
        <?php foreach ($errors as $error): ?>
            <div style="color: indianred;"><?= $error ?></div>
        <?php endforeach; ?>
    <?php endif; ?>
    <input type="submit">
</form>