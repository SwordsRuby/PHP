<?php

include_once('connection/database.php'); 

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php include_once('includes/header.php'); ?>


<?php 

if (isset($_GET['page'])){
    $page = $_GET['page'];

    $massive = ['add_product', 'delete_product', 'product', 'edit_product'];

    if(in_array( $page, $massive)){
        include_once("pages/$page.php");
    }else{
        include_once('pages/404.php');
    }
}else{
    include_once('pages/main.php');
}

?>
</body>
</html>