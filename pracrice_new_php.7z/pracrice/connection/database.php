<?php

$host = 'localhost';
$dbname = 'pracrice';
$username = 'root';
$password = '';

try{
    $database = new PDO("mysql:host=$host;dbname=$dbname;charset", $username, $password);
}catch (PDOException $error){
    die('Ошибка подключения к БД' . $error->getMessage());
}

?>