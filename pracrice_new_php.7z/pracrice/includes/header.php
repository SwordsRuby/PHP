<header>
    <a href="./">Главная</a>
    <a href="./?page=add_product">Добавление продукта</a>
    <a href=""></a>
</header>