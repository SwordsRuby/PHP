<?php

define('USE_SESSION', true);

$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890abcdefghijklmnopqrstuvwxyz';
$length = 6;
$code = substr(str_shuffle($chars), 0, $length);

if (USE_SESSION) {
  session_start();
  $_SESSION['captcha'] =  crypt($code, '$1$itchief$7');
  session_write_close();
} else {
  $value = crypt($code, '$1$itchief$7');
  $expires = time() + 600;
  setcookie('captcha', $value, $expires, '/', 'test.ru', false, true);
}

$image = imagecreatefromjpeg(__DIR__ . '/../img/bg.jpg');
$size = 120;
$color = imagecolorallocate($image, 0, 0, 0);
$font = __DIR__ . '/files//oswald.ttf';
$angle = rand(-10, 10);
$x = 100;
$y = 200;
imagefttext($image, $size, $angle, $x, $y, $color, $font, $code);
header('Content-Type: image/png');
imagepng($image);
imagedestroy($image);



// $stamp = imagecreatefrompng(__DIR__ . '/../img/favicon.png');
// $im = imagecreatefromjpeg(__DIR__ . '/../img/photo.jpg');

// $marge_right = 10;
// $marge_bottom = 10;
// $sx = imagesx($stamp);
// $sy = imagesy($stamp);

// imagecopy($im, $stamp, imagesx($im) - $sx - $marge_right, imagesy($im) - $sy - $marge_bottom, 0, 0, imagesx($stamp), imagesy($stamp));

// header('Content-Type: image/png');
// imagepng($im);
// imagedestroy($im);
