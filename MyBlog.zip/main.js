function deleteConfirm() {
    const conf_block = document.getElementsByClassName('confirm_block');
    conf_block[0].classList.toggle('show');
}