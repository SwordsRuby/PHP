<?
try {
    $dsn = "mysql:host=MySQL-8.2;dbname=bookShopDB;charset=utf8;";
    $username = "root";
    $password = "";
    $sql = new PDO($dsn, $username, $password);
} catch (PDOException $e) {
    die($e->getMessage());
}
