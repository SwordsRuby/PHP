<header>
    <div class="header_block container main_subblock">
        <a href="#"> <img src="../img/logo.png" alt="" class="logo"></a>

        <nav>
            <a href="index.php?url=main">Главная</a>
            <a href="index.php?url=catalog">Каталог</a>
            <a href="index.php?url=main#about_us">О нас</a>
            <a href="index.php?url=main#contacts">Контакты</a>
        </nav>

        <? if (isset($_SESSION["name_user"]) && isset($_SESSION["img_user"])): ?>
            <form method="post">
                <input type="hidden" value="true" name="log_out">
                <input class="button_auth" type="submit" value="Выход из аккаунта">
            </form>
        <? else: ?>
            <a onclick="auth()" href="index.php?auth=true&url=<?= isset($_GET['url']) ? $_GET['url'] : "main"; ?><?= isset($_GET['id']) ? ('&id=' . $_GET['id']) : ""; ?>"><img src="../img/auth_reg.png" alt="" class="auth_reg"></a>
        <? endif; ?>
    </div>
</header>