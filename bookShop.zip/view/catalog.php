<? require("action/catalog_action.php"); ?>
<!-- filter -->
<form method="post" class="filter container main_block">
    <div class="search_block">
        <input value="<?= isset($_GET['search']) ? $_GET['search'] : ""; ?>" class="search" name="search"
            placeholder="Поиск" type="text">
        <input value=" " class="search_submit" type="submit">
    </div>

    <div class="filter_block main_subblock">
        <label class="label" for="genre">
            Жанр:
            <select name="genre">
                <option value="Все">Все</option>
                <? foreach ($books_genre as $genre): ?>
                    <option <?= (isset($_GET['genre']) && $_GET['genre'] == $genre['book_genre']) ? 'selected' : ""; ?>
                        value="<?= $genre['book_genre'] ?>"><?= $genre['book_genre'] ?></option>
                <? endforeach; ?>
            </select>
        </label>

        <label class="label" for="author">
            Автор:
            <select name="author">
                <option value="Все">Все</option>
                <? foreach ($books_author as $author): ?>
                    <option <?= (isset($_GET['author']) && $_GET['author'] == $author['book_author']) ? 'selected' : ""; ?>
                        value="<?= $author['book_author'] ?>"><?= $author['book_author'] ?></option>
                <? endforeach; ?>
            </select>
        </label>

        <label class="label" for="price">
            Цена:
            <div class="price_block">
                <label for="price_min">
                    от
                    <input required="required" maxlength="6" minlength="0"
                        value="<?= isset($_GET['price_min']) ? $_GET['price_min'] : $books_price_min['MIN(book_price)']; ?>"
                        type="number" name="price_min">
                </label>

                <label for="price_max">
                    до
                    <input required="required" maxlength="6" minlength="0"
                        value="<?= isset($_GET['price_max']) ? $_GET['price_max'] : $books_price_max['MAX(book_price)']; ?>"
                        type="number" name="price_max">
                </label>
            </div>
        </label>
    </div>
</form>
<!-- filter -->

<!-- catalog -->
<div id="main_catalog" class="catalog main_block container my_120">
    <div class="catalog_block">
        <? if (!empty($books)): ?>
            <? foreach ($books as $book): ?>
                <!-- card -->
                <a href="index.php?url=product_card&id=<?= $book['book_id'] ?>">
                    <div class="catalog_card">
                        <img src="<?= $book['book_img_1'] ?>" alt="book">
                        <h2 class="book_title"><?= $book['book_title'] ?></h2>
                        <h3><?= $book['book_author'] ?></h3>
                        <hr>
                        <div class="catalog_card_subblock">
                            <h2><?= $book['book_price'] ?> <span class="price">₽</span> </h2>
                            <button>Заказать</button>
                        </div>
                    </div>
                </a>
                <!-- card -->
            <? endforeach; ?>
        <? else: ?>
                    <h2 class="header_catalog">Книг не найдено</h2>
        <? endif; ?>
    </div>
</div>
<!-- catalog -->