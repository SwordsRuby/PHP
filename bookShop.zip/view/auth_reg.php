<!-- authorization -->
<form class="form" id="auth" method="post">
    <button onclick="authRegNone()" class="close"></button>
    <div class="form_block">
        <h1>Авторизация</h1>
        <input class="input_text" placeholder="логин" required="required" autocomplete="off" type="text" name="login_auth">
        <input class="input_text" placeholder="пароль" required="required" autocomplete="off" type="password" name="password_auth">
        <h2>Нет аккаунта? <button onclick="reg()">Зарегистрируйтесь!</button></h2>
        <input class="input_submit margin_top" type="submit" value="Войти">
    </div>
</form>
<!-- authorization -->

<!-- registration -->
<form class="form" id="reg" method="post">
    <button onclick="authRegNone()" class="close"></button>
    <div class="form_block">
        <h1>Регистрация</h1>
        <input class="input_text" placeholder="логин" required="required" autocomplete="off" type="text" name="login_reg">
        <input class="input_text" placeholder="пароль" required="required" autocomplete="off" type="password" name="password_reg">
        <input class="input_text" placeholder="подтвердите пароль" required="required" autocomplete="off" type="password" name="password_reg_repeated">
        <h2 class="width">Регистрируясь на сайте, вы принимайте <a class="link_document" href="../document/political.docx">публичную оферту</a> </h2>
        <input class="input_submit" type="submit" value="Зарегистрироваться">
    </div>
</form>
<!-- registration -->