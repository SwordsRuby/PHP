<? require("action/index_action.php"); ?>
<!-- main -->
<main>
    <!-- banner -->
    <div class="banner">
        <div class="banner_slider_wraper">
            <div id="banner_slider_block" class="banner_slider_block">
                <? foreach ($banner_books as $book): ?>
                    <div class="banner_block container main_subblock">
                        <div class="banner_info_subblock">
                            <h1><?= $book['book_title'] ?></h1>
                            <p><?= $book['book_discription'] ?></p>
                            <button>Заказать</button>
                        </div>

                        <img src="<?= $book['book_img_1'] ?>" alt="book">
                    </div>
                <? endforeach; ?>
            </div>
        </div>


        <div class="pagination">
            <button onclick="sliderActive('0px', this)" class="dot dot_active"></button>
            <button onclick="sliderActive('-1200px', this)" class="dot"></button>
            <button onclick="sliderActive('-2400px', this)" class="dot"></button>
            <button onclick="sliderActive('-3600px', this)" class="dot"></button>
            <button onclick="sliderActive('-4800px', this)" class="dot"></button>
            <button onclick="sliderActive('-6000px', this)" class="dot"></button>
        </div>
    </div>
    <!-- banner -->

    <!-- company -->
    <div id="about_us" class="company container my_120">
        <div class="company_block main_block">
            <h2 class="main_title">О нас</h2>
            <p>
                Магазин "Грезы" — это уютное место, где каждый найдет что-то особенное для себя или в подарок.
                Ассортимент включает уникальные аксессуары, авторские изделия, предметы декора и арт-объекты, которые
                помогают создать атмосферу вдохновения и уюта. В "Грезах" собраны товары местных мастеров и творческих
                людей, что придаёт каждому изделию особую ценность и оригинальность.
            </p>
        </div>
    </div>
    <!-- company -->

    <!-- catalog -->
    <div id="catalog" class="catalog main_block container my_120">
        <h2 class="catalog_title main_title">Каталог</h2>

        <div class="catalog_block">
            <? foreach ($books as $book): ?>
                <!-- card -->
                <a href="index.php?url=product_card&id=<?= $book['book_id'] ?>">
                    <div class="catalog_card">
                        <img src="<?= $book['book_img_1'] ?>" alt="book">
                        <h2 class="book_title"><?= $book['book_title'] ?></h2>
                        <h3><?= $book['book_author'] ?></h3>
                        <hr>
                        <div class="catalog_card_subblock">
                            <h2><?= $book['book_price'] ?> <span class="price">₽</span> </h2>
                            <button>Заказать</button>
                        </div>
                    </div>
                </a>
                <!-- card -->
            <? endforeach; ?>
        </div>

        <a class="catalog_button" href="index.php?url=catalog">Перейти в каталог</a>
    </div>
    <!-- catalog -->

    <!-- map -->
    <div id="contacts" class="map container my_120">
        <div class="map_block">
            <h2 class="main_title">Контакты</h2>
            <a href="mailto:legend_magazine@gmail.com">dreams_books@gmail.com</a>
            <div>
                <p><span class="bold">Пн – Пт:</span>  09:00 – 21:00</p>
                <p><span class="bold">Сб – Вс:</span>  10:00 – 18:00</p>
            </div>
            <p>420111, Республика Татарстан, Казань, Кремль, а/я 522</p>
        </div>
    </div>
    <!-- map -->
</main>
<!-- main -->