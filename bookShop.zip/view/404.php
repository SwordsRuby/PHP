<div class="block_404">
    <h1>404 ERROR</h1>
    <a href="index.php?url=main">Вернуться на главную</a>
</div>