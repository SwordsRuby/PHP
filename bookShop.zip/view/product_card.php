<? require('action/product_card_action.php'); ?>

<!-- product_card -->
<div class="product_card_block container main_subblock">
    <div class="img_block">
        <div class="img_subblock">
            <? if (!empty($book_card['book_img_2'])): ?>
                <img class="book_img" onclick="imgSwap(this)" src="<?= $book_card['book_img_2'] ?>" alt="book">
            <? endif; ?>
            <? if (!empty($book_card['book_img_3'])): ?>
                <img class="book_img" onclick="imgSwap(this)" src="<?= $book_card['book_img_3'] ?>" alt="book">
            <? endif; ?>
            <? if (!empty($book_card['book_img_4'])): ?>
                <img class="book_img" onclick="imgSwap(this)" src="<?= $book_card['book_img_4'] ?>" alt="book">
            <? endif; ?>
        </div>

        <img id="main_img" src="<?= $book_card['book_img_1'] ?>" alt="book">
    </div>

    <div class="product_card_subblock">
        <h1><?= $book_card['book_title'] ?></h1>
        <h2><?= $book_card['book_author'] ?></h2>
        <h2><?= $book_card['book_genre'] ?></h2>
        <div class="text_block">
            <div id="background_block"></div>
            <p><?= $book_card['book_discription'] ?></p>
            <button onclick="textSee(this)">Показать ещё</button>
        </div>
        <div class="catalog_card_subblock prod_card_subblock">
            <h2><?= $book_card['book_price'] ?> <span class="price">₽</span> </h2>
            <button>Заказать</button>
        </div>
    </div>
</div>
<!-- product_card -->