<footer class="my_120">
    <div class="footer_block container main_subblock">
        <a href="#"> <img src="../img/logo.png" alt="" class="logo"></a>

        <nav>
            <a href="index.php?url=main">Главная</a>
            <a href="index.php?url=catalog">Каталог</a>
            <a href="index.php?url=main#about_us">О нас</a>
            <a href="index.php?url=main#contacts">Контакты</a>
        </nav>

        <p>© Шарафиев А.Р</p>
    </div>
</footer>