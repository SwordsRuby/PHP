<?
$query = "SELECT DISTINCT book_author FROM books";
$stmt = $sql->prepare($query);
$stmt->execute();
$books_author = $stmt->fetchAll();

$query = "SELECT DISTINCT book_genre FROM books";
$stmt = $sql->prepare($query);
$stmt->execute();
$books_genre = $stmt->fetchAll();

$query = "SELECT MAX(book_price) FROM books";
$stmt = $sql->prepare($query);
$stmt->execute();
$books_price_max = $stmt->fetch();

$query = "SELECT MIN(book_price) FROM books";
$stmt = $sql->prepare($query);
$stmt->execute();
$books_price_min = $stmt->fetch();

if (isset($_POST['price_min'])) {
    $url = 'index.php?url=catalog';

    if ($books_price_min['MIN(book_price)'] < $_POST['price_min']) {
        $_GET['price_min'] = $_POST['price_min'];
        $url .= '&price_min=' . $_POST['price_min'];
    }
    if ($books_price_max['MAX(book_price)'] > $_POST['price_max']) {
        $_GET['price_max'] = $_POST['price_max'];
        $url .= '&price_max=' . $_POST['price_max'];
    }
    if ($_POST['author'] != 'Все') {
        $_GET['author'] = $_POST['author'];
        $url .= '&author=' . $_POST['author'];
    }
    if ($_POST['genre'] != 'Все') {
        $_GET['genre'] = $_POST['genre'];
        $url .= '&genre=' . $_POST['genre'];
    }
    if (!empty($_POST['search'])) {
        $_GET['search'] = $_POST['search'];
        $url .= '&search=' . $_POST['search'];
    }

    header("Location: " . $url);
}

$query = "SELECT book_id, book_price, book_title, book_img_1, book_author FROM books WHERE book_title LIKE '%' ";

if (isset($_GET['genre'])) {
    $query .= "AND book_genre = :book_genre ";
}
if (isset($_GET['author'])) {
    $query .= "AND book_author = :book_author ";
}
if (isset($_GET['price_min'])) {
    $query .= "AND book_price >= :price_min ";
}
if (isset($_GET['price_max'])) {
    $query .= "AND book_price <= :price_max ";
}
if (isset($_GET['search'])) {
    $query .= " AND book_title LIKE :book_title ";
}

$stmt = $sql->prepare($query);

if (isset($_GET['genre'])) {
    $stmt->bindParam(':book_genre', $_GET['genre']);
}
if (isset($_GET['author'])) {
    $stmt->bindParam(':book_author', $_GET['author']);
}
if (isset($_GET['price_min'])) {
    $stmt->bindParam(':price_min', $_GET['price_min']);
}
if (isset($_GET['price_max'])) {
    $stmt->bindParam(':price_max', $_GET['price_max']);
}
if (isset($_GET['search'])) {
    $search = '%' . $_GET['search'] . '%';
    $stmt->bindParam(':book_title', $search);
}

$stmt->execute();
$books = $stmt->fetchAll();