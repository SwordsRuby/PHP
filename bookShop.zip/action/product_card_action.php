
<?
$query = "SELECT * FROM books WHERE book_id = :id";
$stmt = $sql->prepare($query);
$stmt->bindParam(":id", $_GET['id']);
$stmt->execute();
$book_card = $stmt->fetch();
