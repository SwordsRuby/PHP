<?
$query = "SELECT book_id, book_discription, book_title, book_img_1 FROM books ORDER BY book_id DESC LIMIT 6";
$stmt = $sql->prepare($query);
$stmt->execute();
$banner_books = $stmt->fetchAll();

$query = "SELECT book_id, book_price, book_title, book_img_1, book_author FROM books LIMIT 6";
$stmt = $sql->prepare($query);
$stmt->execute();
$books = $stmt->fetchAll();

if (!isset($_GET['url'])) {
    $_GET['url'] = 'main';
}
$url = $_GET['url'];

if (isset($_POST['log_out'])) {
    echo "<script> alert('Выход из аккаунта совершён'); </script>";
    unset($_SESSION["name_user"]);
    unset($_SESSION["img_user"]);
    header("Location: index.php?url=$url");
}

if (isset($_POST['login_auth']) && isset($_POST['password_auth'])) {
    $query_authorization = "SELECT * FROM `authorization` WHERE :login_user = `login`";
    $stmt = $sql->prepare($query_authorization);
    $stmt->bindParam(":login_user", $_POST['login_auth']);
    $stmt->execute();
    $user = $stmt->fetch();

    if (!empty($user) && isset($_POST['password_auth'])) {
        if ($user['pass'] == $_POST['password_auth'] && $user['stat'] == "user") {
            $_SESSION["name_user"] = $user['login'];
            $_SESSION["img_user"] = $user['img_user'];
            $_SESSION["admin"] = false;
            header("Location: index.php?url=$url");
        } else {
            echo "<script> alert('Неправильный пароль или имя пользователя'); </script>";
        }
    } else {
        echo "<script> alert('Неправильный пароль или имя пользователя'); </script>";
    }
}


if (isset($_POST['login_reg']) && isset($_POST['password_reg']) && isset($_POST['password_reg_repeated'])) {
    if ($_POST['password_reg'] == $_POST['password_reg_repeated']) {
        $query_reg = "INSERT INTO `authorization` (`login`, `pass`, `stat`) VALUE (:login_reg, :password_reg, 'user')";

        $stmt = $sql->prepare($query_reg);
        $stmt->bindParam(":login_reg", $_POST['login_reg']);
        $stmt->bindParam(":password_reg", $_POST['password_reg']);
        $stmt->execute();
        header("Location: index.php?url=$url&auth=true");
    } else {
        echo "<script> alert('Пароли не совпадают'); </script>";
    }
}
