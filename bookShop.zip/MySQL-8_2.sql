-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: MySQL-8.2
-- Generation Time: Feb 12, 2025 at 11:07 PM
-- Server version: 8.2.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookShopDB`
--
CREATE DATABASE IF NOT EXISTS `bookShopDB` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `bookShopDB`;

-- --------------------------------------------------------

--
-- Table structure for table `authorization`
--

CREATE TABLE `authorization` (
  `login` char(50) NOT NULL,
  `pass` char(50) DEFAULT NULL,
  `stat` char(20) NOT NULL,
  `img_user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYAhBdjd5Dc183RfLQZmtTfkKt34zxUU5iEw&s'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `authorization`
--

INSERT INTO `authorization` (`login`, `pass`, `stat`, `img_user`) VALUES
('root', '123456', 'admin', 'https://avatars.mds.yandex.net/i?id=d076d16d9fbe57a17605768171da2a9a_l-5221765-images-thumbs'),
('user123', '12345678', 'user', 'https://cdn1.flamp.ru/c564ba45697d44877dd81d2cb274d47b.jpg'),
('user23423', 'kill', 'user', 'https://image.winudf.com/v2/image/Y29tLmNhbWVyYS54aWFvbWlfc2NyZWVuXzBfMTUyMTg0MjgwMl8wMjU/screen-0.jpg?fakeurl=1'),
('user34', 'qwerty', 'user', 'https://i.pinimg.com/originals/c5/2e/e2/c52ee2866efbfa28a0e94d6a730e05f2.jpg'),
('you123', '1234', 'user', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYAhBdjd5Dc183RfLQZmtTfkKt34zxUU5iEw&s');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int NOT NULL,
  `book_title` varchar(50) NOT NULL,
  `book_discription` varchar(800) NOT NULL,
  `book_price` int NOT NULL,
  `book_author` varchar(50) NOT NULL,
  `book_genre` varchar(50) NOT NULL,
  `book_img_1` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'https://cdn-icons-png.flaticon.com/512/2933/2933275.png',
  `book_img_2` varchar(2000) DEFAULT NULL,
  `book_img_3` varchar(2000) DEFAULT NULL,
  `book_img_4` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `book_title`, `book_discription`, `book_price`, `book_author`, `book_genre`, `book_img_1`, `book_img_2`, `book_img_3`, `book_img_4`) VALUES
(1, 'Марионетки', 'Лишь год потребовался Стеше на адаптацию в новом мире. Теперь у нее есть собственный дом на берегу озера, новые друзья, новые увлечения и новые мечты. У нее есть будущее, от которого захватывает дух. Но насладиться жизнью сполна не получается. Каждую ночь туман приносит смрад болотных испарений. Каждую ночь верный пёс покрывается броней и ложится у порога, не впуская тьму в их новый дом. И можно сколько угодно убеждать себя, что все в порядке, но от правды не скрыться! Стеше необходимо вернуться на болото, чтобы защитить друзей и докопаться до правды.', 399, 'Татьяна Корсакова', 'Ужасы', 'https://cdn.litres.ru/pub/c/cover_415/71456731.webp', '', '', ''),
(2, 'Благодать', 'Впервые на русском – роман современного ирландского классика Пола Линча, лауреата Букеровской премии 2023 года за роман «Песнь пророка», который уже называют «ирландским „1984“» и «новым „Рассказом служанки“». От «одного из величайших писателей современности» (Marianne) – «эпическая фреска, плутовской роман и захватывающая история взросления одновременно» (La Vie). Итак, познакомьтесь с четырнадцатилетней Грейс. Однажды морозным утром мать выволакивает ее на улицу, остригает ей волосы, велит переодеться в мужскую одежду и отправиться в путь – иначе в Ирландии на заре Великого голода ей не выжить.', 449, 'Пол Линч', 'Триллер', 'https://cdn.litres.ru/pub/c/cover_415/71479564.webp', NULL, NULL, NULL),
(3, 'Скотный двор', 'Скотный двор – сатирическая притча Джорджа Оруэлла, рассказывающая о домашних животных, восставших против фермера в надежде построить общество, в котором не будет места жестокости и неравенству. Однако одна тирания сменилась другой, а вожделенное светлое будущее теперь кажется еще более недосягаемым, чем прежде.', 562, ' Оруэлл Джордж', 'Антиутопия', 'https://ir-3.ozone.ru/s3/multimedia-y/wc1000/6040718482.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-a/wc1000/6994487242.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-w/wc1000/6994487156.jpg', NULL),
(4, 'Божественная комедия', '\"Когда-то я в годину зрелых лет\r\nВ дремучий лес зашел и заблудился…\"\r\n– так начинается \"Божественная комедия\", бессмертная поэтическая трилогия, в которой Данте дерзко переосмыслил средневековую традицию \"хождений\" по загробному миру и религиозных \"видений\", и создал поистине уникальное произведение, в котором мистика сочетается с философией, а притча – с весьма ядовитым политическим памфлетом. \r\nПрошли века. Политическая злободневность \"Божественной комедии\" давно пропала, но остались и бессмертная красота языка Данте, и мощь его литературного таланта, и сила философской мысли, предвосхитившей духовные и нравственные искания гуманистических гениев Возрождения. ', 341, 'Алигьери Данте', 'Классика', 'https://ir-3.ozone.ru/s3/multimedia-1-f/wc1000/7058548887.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-2/wc1000/7058548910.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-d/wc1000/7058548921.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-j/wc1000/7058548891.jpg'),
(5, 'Мастер и Маргарита', 'Бессмертное, загадочное и остроумное «Евангелие от Сатаны» Михаила Булгакова.\r\nРоман, уникальный в российской литературе ХХ столетия. Трудно себе представить, какое влияние он оказал на мировую культуру.\r\nНа основе «Мастера и Маргариты» снимались и продолжают сниматься фильмы и телесериалы, это произведение легло в основу оперы, симфонии, рок-оперы, его иллюстрировали самые знаменитые художники и фотографы. \r\nДостаточно перечислить лишь немногих создателей произведений, посвященных шедевру Булгакова и им вдохновленных: Анджей Вайда, Эннио Морриконе, Мик Джаггер, Дэвид Боуи.', 362, 'Булгаков Михаил Афанасьевич', 'Классика', 'https://ir-3.ozone.ru/s3/multimedia-8/wc1000/6832419920.jpg', 'https://ir-3.ozone.ru/s3/multimedia-b/wc1000/6832419923.jpg', 'https://ir-3.ozone.ru/s3/multimedia-l/wc1000/6832419897.jpg', 'https://ir-3.ozone.ru/s3/multimedia-g/wc1000/6832419928.jpg'),
(6, 'Зов Ктулху', 'Лучшие произведения Лавкрафта. Они бесконечно разнообразны и многогранны. Одни относятся к классическому \"черному неоромантизму\", другие — к \"викторианской\" литературе ужасов. Одни представляют собой попытки научной фантастики, другие относятся к чистой мистике. Но в каждом из них живет гений писателя, подарившего нам лишь на шаг отстоящий от реальности причудливый мир \"богов-демонов\" — Подводного Ктулху и безликого Азатота, таинственного Шуб-Ниггурата и великого Йог-Сотота.', 259, 'Лавкрафт Говард Филлипс', 'Классика', 'https://ir-3.ozone.ru/s3/multimedia-e/wc1000/6853534358.jpg', 'https://ir-3.ozone.ru/s3/multimedia-e/wc1000/6302868122.jpg', 'https://ir-3.ozone.ru/s3/multimedia-f/wc1000/6853534575.jpg', 'https://ir-3.ozone.ru/s3/multimedia-k/wc1000/6302868164.jpg'),
(7, 'Отцы и дети', '«Вся моя повесть направлена против дворянства как передового класса. Вглядитесь в лица Николая Петровича, Павла Петровича, Аркадия. Слабость и вялость или ограниченность», — так Тургенев разъясняет замысел своего романа. Причем берет он «именно хороших представителей дворянства», показывая: «Если сливки плохи, что же молоко?» ', 251, 'Тургенев Иван Сергеевич', 'Классика', 'https://ir-3.ozone.ru/s3/multimedia-1/wc1000/6810585265.jpg', 'https://ir-3.ozone.ru/s3/multimedia-m/wc1000/6810585214.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-f/wc1000/7107147843.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-p/wc1000/7107147889.jpg'),
(8, 'Гордость и предубеждение', '﻿Шедевр английской литературы \"Гордость и предубеждение\" был впервые опубликован в 1813 году и до сих пор не теряет своего обаяния, оставаясь одним из самых популярных романов всех времен. Остроумная комедия нравов, вышедшая из-под пера Джейн Остен, получила значительное внимание со стороны критиков и проложила путь к тем прообразам, которые можно найти и в современной литературе.', 193, 'Остен Джейн', 'Классика', 'https://ir-3.ozone.ru/s3/multimedia-j/wc1000/6032781835.jpg', 'https://ir-3.ozone.ru/s3/multimedia-l/wc1000/6032781837.jpg', 'https://ir-3.ozone.ru/s3/multimedia-m/wc1000/6032781838.jpg', 'https://ir-3.ozone.ru/s3/multimedia-n/wc1000/6032781839.jpg'),
(9, 'Юмористические рассказы', 'Премьерный сборник рассказов писателя был подготовлен к печати, но в свет так и не вышел... Чехов писал: «В Москве находятся издатели-типографы, но в Москве цензура книги не пустит, ибо все мои отборные рассказы, по московским понятиям, подрывают основы». Но искрометный, остроумный юмор Антона Чехова заряжает позитивным отношением к человеческой природе, несмотря на присущие всем нам недостатки и заблуждения.', 266, 'Чехов Антон Павлович', 'Классика', 'https://ir-3.ozone.ru/s3/multimedia-y/wc1000/6725817034.jpg', 'https://ir-3.ozone.ru/s3/multimedia-z/wc1000/6725817035.jpg', 'https://ir-3.ozone.ru/s3/multimedia-a/wc1000/6139039354.jpg', 'https://ir-3.ozone.ru/s3/multimedia-9/wc1000/6139039353.jpg'),
(10, 'Братья Карамазовы Том 1', 'Последний роман Достоевского, подводящий итог его творчеству и поднимающий вечные вопросы человечества, и духовное завещание писателя, ставшее важной вехой в мировой литературе. \r\nСпор о наследстве сводит под крышей монастыря помещика Федора Павловича Карамазова, сластолюбца и приживальщика, и трех его сыновей — Дмитрия, Ивана и Алексея.', 428, 'Достоевский Федор Михайлович', 'Классика', 'https://ir-3.ozone.ru/s3/multimedia-1-y/wc1000/7163449954.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-r/wc1000/7153227315.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-j/wc1000/7194594835.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-5/wc1000/7194594821.jpg'),
(11, 'Любимый незнакомец', 'История любви, которая разворачивается на фоне Великой депрессии и поиска серийного убийцы.\r\nВпервые исторический детектив от королевы сентиментальной прозы Эми Хармон.\r\n1923 год, Чикаго. Родители десятилетней Дани Флэнаган погибли при загадочных обстоятельствах. Тогда офицера Майкла Мэлоуна заставили замолчать и дело быстро закрыли.\r\nПятнадцать лет спустя в Кливленде происходят убийства при схожих обстоятельствах. Дороги Дани и Майкла вновь пересекаются. Теперь сомнений нет: в городе орудует маньяк.', 278, 'Хармон Эми', 'Роман', 'https://ir-3.ozone.ru/s3/multimedia-w/wc1000/6649856276.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-m/wc1000/7021054498.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-v/wc1000/7021054507.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-q/wc1000/7021054502.jpg'),
(12, 'Маленькие женщины', 'Трогательная книга, которая читается с улыбкой на лице. Светлая история, которая вселяет надежду. Доброе чтение, которое отвлекает от бед и погружает в атмосферу уюта и тепла. Сюжет «Маленьких женщин» словно создан для моментов, когда очень хочется, чтобы жизнь наполнилась позитивными эмоциями.', 249, 'Олкотт Луиза Мэй', 'Классика', 'https://ir-3.ozone.ru/s3/multimedia-m/wc1000/6724052302.jpg', 'https://ir-3.ozone.ru/s3/multimedia-o/wc1000/6724052304.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-i/wc1000/6936959466.jpg', 'https://ir-3.ozone.ru/s3/multimedia-1-v/wc1000/6936959659.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int NOT NULL,
  `order_username` varchar(50) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order_book_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authorization`
--
ALTER TABLE `authorization`
  ADD PRIMARY KEY (`login`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
