<?
if (session_status() == PHP_SESSION_NONE)
    session_start();
require("database/db.php");
require("action/index_action.php");
?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Грезы</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- header -->
    <? require('view/header.php'); ?>
    <!-- header -->

    <!-- main -->
    <?
    // require page
    if (isset($_GET['id']) && !empty($_GET['id'])) {
        require('view/product_card.php');
    } elseif (isset($_GET['url'])) {
        if ($_GET['url'] == 'catalog') {
            require('view/catalog.php');
        } elseif ($_GET['url'] == 'main') {
            require('view/main.php');
        } else {
            require('view/404.php');
        }
    } else {
        require('view/main.php');
    }

    // require authorization and registration
    if (isset($_GET['auth']) && $_GET['auth'] == 'true') {
        require('view/auth_reg.php');
    }
    ?>
    <!-- main -->


    <!-- footer -->
    <? require('view/footer.php'); ?>
    <!-- footer -->


    <!-- script -->
    <script src="../js/main.js"></script>
    <!-- script -->
</body>

</html>